package data;

import java.util.ArrayList;

import query.Query;

public class DataManager {

	public static ArrayList<Query> getQueryList() {
		ArrayList<Query> q = new ArrayList<Query>();
		
		return q;
	}
	
}
